<?php 

require_once './db.php';

$id = (isset($_GET['id'])) ? $_GET['id'] : '';

if ($id == '') {
	echo "<a href='index.php'>Back to List</a>";
	echo "<br>";
	die("invalid id");
}

$sql = "SELECT * FROM tbl_persons WHERE id = '{$id}'";

$result = $mysql->query($sql);

if ($result->num_rows != 1) {
	echo "<a href='index.php'>Back to List</a>";
	echo "<br>";
	die("invalid id");
}

$record = $result->fetch_assoc();

extract($record);

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CURD Example - FORM</title>
</head>
<body>

<h1>Guest Book Edit</h1>

<form action="process.php" method="post">
<input type="hidden" name="id" value="<?php echo $id;?>">
<table>
	<tr>
		<td>Name</td>
		<td><input type="text" name="name" value="<?php echo $name;?>"></td>
	</tr>
	<tr>
		<td>Address</td>
		<td><input type="text" name="address" value="<?php echo $address;?>"></td>
	</tr>
	<tr>
		<td>Phone</td>
		<td><input type="text" name="phone" value="<?php echo $phone;?>"></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="text" name="email" value="<?php echo $email;?>"></td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="submit" name="submit" value="Submit">
		</td>
	</tr>
</table>
</form>
</body>
</html>