<?php

require_once './db.php';

$sql = "SELECT * FROM tbl_persons";

$results = $mysql->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link type="text/css" rel="stylesheet" href="http://l.kcceval.com/assets/third_party/bootstrap-3.3.7/css/bootstrap.min.css"  />
	<title>Person List</title>
</head>
<body>

<h1>Person List Page</h1>

<a href="add.php" class="btn btn-primary btn-sm">Add New Person</a>


<?php if ($results->num_rows == 0): ?>

<h3>No Records found</h3>

<?php else: ?>
<table class="table">
	<thead>
		<tr>
			<td>SN</td>
			<td>Name</td>
			<td>Address</td>
			<td>Phone</td>
			<td>Email</td>
			<td>Action</td>
		</tr>
	</thead>
	<tbody>	
	<?php $sn = 1; ?>
	<?php while($row = $results->fetch_assoc()):?>
		<tr>
			<td><?php echo $sn++;?></td>
			<td><?php echo $row['name'];?></td>
			<td><?php echo $row['address'];?></td>
			<td><?php echo $row['phone'];?></td>
			<td><?php echo $row['email'];?></td>
			<td>
				<a href="edit.php?id=<?php echo $row['id'];?>">Edit</a>
				<a href="delete.php?id=<?php echo $row["id"]; ?>" onclick="return confirmDelete()">Delete</a>  
			</td>
		</tr>
	<?php endwhile;?>
	</tbody>
	
</table>
<?php endif;?>

<script>
function confirmDelete(){
	var res = confirm('Are you sure?');
	if (!res)
		return false;
	return true;
}
</script>

</body>
</html>