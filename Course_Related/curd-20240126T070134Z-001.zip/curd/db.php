<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'kcc';

/*
$mysql = mysqli_connect($host, $user, $pass, $db);

if (!$mysql) {
	die ('Could not connect to db server');
}
*/


$mysql = new mysqli($host, $user, $pass, $db);

if ($mysql->connect_error) {
	die ('Could not connect to db server' . $mysql->connect_error);
}

