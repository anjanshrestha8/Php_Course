<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CURD Example - FORM</title>
</head>
<body>

<h1>Guest Book Add</h1>

<form action="process.php" method="post">
<table>
	<tr>
		<td>Name</td>
		<td><input type="text" name="name"></td>
	</tr>
	<tr>
		<td>Address</td>
		<td><input type="text" name="address"></td>
	</tr>
	<tr>
		<td>Phone</td>
		<td><input type="text" name="phone"></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="text" name="email"></td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="submit" name="submit" value="Submit">
		</td>
	</tr>
</table>
</form>
</body>
</html>