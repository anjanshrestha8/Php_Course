<?php
require_once  './db.php';

extract($_POST);


if (isset($id)) {
	# update

	print $sql = "UPDATE tbl_persons SET name = '{$name}', address = '{$address}', phone = '{$phone}', email = '{$email}' WHERE id = $id";
} else {
	# insert

	$sql = "INSERT INTO tbl_persons (id, name, address, phone, email) VALUES (NULL, '$name', '$address', '$phone', '$email')";
}


$result = $mysql->query($sql);

header('Location: index.php');
