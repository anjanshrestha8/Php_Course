<?php 

require_once './db.php';

$id = (isset($_GET['id'])) ? $_GET['id'] : '';

if ($id == '') {
	echo "<a href='index.php'>Back to List</a>";
	echo "<br>";
	die("invalid id");
}

$sql = "DELETE FROM tbl_persons WHERE id = '{$id}'";

$result = $mysql->query($sql);

header('Location: index.php');

?>

